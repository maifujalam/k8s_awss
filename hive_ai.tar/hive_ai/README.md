1. Solution1: Please read solution1.txt
2. Solution2: `docker compose up -d`
    
